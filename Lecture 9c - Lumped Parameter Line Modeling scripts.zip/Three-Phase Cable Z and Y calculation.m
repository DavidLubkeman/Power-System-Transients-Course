%  ECE 551
%  Matlab Program for Calculating Cable Parameters
% GMR_phase = 0.0111 feet
% GMR_neutral = 0.0409 feet
% d_phase=0.368 inch
% d_neutral = 0.0641 inches
% Dap,an = 0.0415 feet
% Dap,bn = 0.625 feet
% Dap,cn = 1.25 feet
% R_phase =0.97 Ohms/mile
% R_neutral = 2.4787 Ohms/mile


clear all;

% Earth Resistivity
rho=100;
freq=60;

% Equivalent Distance for Carson's Correction
De=2160*sqrt(rho/freq);

% GMR vector (in ft.) for phases ap,bp,cp,an,bn,cn
GMR = [0.0111 0.0111 0.0111 0.0340 0.03400 0.0340];

% Diameter vector (in feet) for  phases ap,bp,cp,an,bn,cn
% Diameter = [0.368/12 0.368/12 0.368/12 0.0641/12 0.0641/12 0.0641/12];

% Resistance vector (in Ohms/mile) for phases ap,bp,cp,an,bn,cn
R = [0.97 0.97 0.97 2.4787 2.4787 2.4787];

% Set up Conductor Positions using X,Y Coordinates using reference
% at ground level under center conductor
ap=1;
bp=2;
cp=3;
an=4;
bn=5;
cn=6;
D(ap,bp)=0.625;
D(bp,cp)=0.625;
D(an,bn)=0.625;
D(bn,cn)=0.625;
D(ap,cp)=1.25;
D(an,cn)=1.25;
D(ap,an)=0.0415;
D(bp,bn)=0.0415;
D(cp,cn)=0.0415;
D(ap,bn)=.625;
D(bp,cn)=.625;
D(bp,an)=.625;
D(cp,bn)=.625;
D(ap,cn)=1.25;
D(cp,an)=1.25;

% Compute 6x6 Series Impedance Matrix (Before Kron Reduction)
for r=1:6;
	for c=r:6;
		if r==c;
			Zp(r,c)=(R(r)+0.0953)+(0.1213*(log(De/GMR(r))))*i;
		else;
			Zp(r,c)=(0.0953)+(0.1213*(log(De/D(r,c))))*i;
			Zp(c,r)=Zp(r,c);
		end;
	end;
end;

% Perform Kron Reduction to Eliminate Impact of Neutral Wire
A11=Zp(1:3,1:3);
A12=Zp(1:3,4:6);
A21=Zp(4:6,1:3);
A22=Zp(4:6,4:6);

Zred=A11-A12*inv(A22)*A21;

Zs=(Zred(1,1)+Zred(2,2)+Zred(3,3))/3;
Zm=(Zred(1,2)+Zred(1,3)+Zred(2,3))/3;
Z1=Zs-Zm;
Z0=Zs+2*Zm;
Z1/5.28
Z0/5.28

Y=j*77.3619/(log(0.083/0.0307)-(1/6)*log(6*0.00534/0.0830))


