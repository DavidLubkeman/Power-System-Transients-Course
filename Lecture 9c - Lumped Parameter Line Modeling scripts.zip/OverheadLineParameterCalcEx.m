%  Matlab Program for Calculating Line Parameters
%  North Carolina State University - ECE587  

clear all;

% Earth Resistivity
rho=100;
freq=60;

% Equivalent Distance for Carson's Correction
De=2160*sqrt(rho/freq);

% GMR vector (in ft.) for phases a,b,c,ground
GMR = [0.0244 0.0244 0.0244 0.00814];

% Diameter vector (in inches) for  phases a,b,c,ground
Diameter = [0.721 0.721 0.721 0.563];

% Resistance vector (in Ohms/mile) for phases a,b,c,ground
R = [0.306 0.306 0.306 0.592];

% Set up Conductor Positions using X,Y Coordinates using reference
% at ground level under center conductor
Xpos = [-3.67  0.0  3.67  0.5];
Ypos = [ 33.2 34.5 33.2  30.5 ];

% Compute Actual Distances between Conductor Pairs
for r=1:4;
	for c=1:4;
		D(r,c)=sqrt((Xpos(r)-Xpos(c))^2+(Ypos(r)-Ypos(c))^2);
	end;
end;

% Compute 4x4 Series Impedance Matrix (Before Kron Reduction)
for r=1:4;
	for c=1:4;
		if r==c;
			Zp(r,c)=(R(r)+0.0953)+(0.1213*(log(De/GMR(r))))*i;
		else;
			Zp(r,c)=(0.0953)+(0.1213*(log(De/D(r,c))))*i;
		end;
	end;
end;

% Perform Kron Reduction to Eliminate Impact of Neutral Wire
for r=1:3;
	for c=1:3;
		Z(r,c)=Zp(r,c)-(Zp(r,4)*Zp(4,c)/Zp(4,4));
	end;
end;

% Units in terms of miles
Zmatrix=Z
Rmatrix=real(Z);
Lmatrix=imag(Z)/377;

% Compute Distances between Actual Conductors (r) and Images (c)
for r=1:4;
	for c=1:4;
		Dimag(r,c)=sqrt((Xpos(r)-Xpos(c))^2+(Ypos(r)-(-Ypos(c)))^2);
	end;
end;

% Compute 4x4 Capacitive Shunt Impedance Matrix (Before Kron Reduction)
for r=1:4;
	for c=1:4;
		if r==c;
			Zpc(r,c)=-((1.0/(377*2*pi*8.85e-12))*(log(Dimag(r,c)/(Diameter(r)/(2*12)))))*i;
		else;
			Zpc(r,c)=-((1.0/(377*2*pi*8.85e-12))*(log(Dimag(r,c)/D(r,c))))*i;
		end;
	end;
end;


% Perform Kron Reduction to Eliminate Impact of Neutral Wire
for r=1:3;
	for c=1:3;
		Zc(r,c)=Zpc(r,c)-(Zpc(r,4)*Zpc(4,c)/Zpc(4,4));
	end;
end;

% Shunt capacitive impedance in terms of ohm-miles
Zc=Zc/1609;
Ymatrix=imag(inv(Zc))
Cmatrix=imag(inv(Zc)/377);

% Take Average to Compute Self and Mutual Values
Rs=(Rmatrix(1,1)+Rmatrix(2,2)+Rmatrix(3,3))/3;
Rm=(Rmatrix(1,2)+Rmatrix(1,3)+Rmatrix(2,3))/3;
Ls=(Lmatrix(1,1)+Lmatrix(2,2)+Lmatrix(3,3))/3;
Lm=(Lmatrix(1,2)+Lmatrix(1,3)+Lmatrix(2,3))/3;
Cs=(Cmatrix(1,1)+Cmatrix(2,2)+Cmatrix(3,3))/3;
Cm=(Cmatrix(1,2)+Cmatrix(1,3)+Cmatrix(2,3))/3;

% Compute Quanities for Line (positive sequence - 1) Mode
R1=Rs-Rm;
L1=Ls-Lm;
C1=Cs-Cm;
Z1=sqrt(L1/C1);
vl=1/sqrt(L1*C1);

% Compute Quanities for Ground (zero sequence - 0) Mode
R0=Rs+2*Rm;
L0=Ls+2*Lm;
C0=Cs+2*Cm;
Z0=sqrt(L0/C0);
v0=1/sqrt(L0*C0);

% Compute Quantities for PSCAD PI Section Model
RS1=R1/1609.0
XS1=377*L1/1609.0
XC1=1/(377*C1)*1609/1e6
RS0=R0/1609.0
XS0=377*L0/1609
XC0=1/(377*C0)*1609/1e6

% Compute Quantities for Simulink PI Section Model
Rs=Rs/1609.0
Rm=Rm/1609.0
Ls_mh=1000*Ls/1609.0
Lm_mh=1000*Lm/1609.0
Cs_uf=1.0e6*Cs/1609.0
Cm_uf=1.0e6*Cs/1609.0
