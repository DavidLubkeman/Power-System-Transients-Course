clear all;
% part 1, problem 2
R=input('Input the resistance in ohms: ');
L=input('Input the inductance in henrys: ');
C=input('Input the capacitance in farads: ');
Vm=input('Input the Voltage Magnitude: ');
w=input('Input the ang. freq : ');
ang=input('Input the Voltage angle: ');

phi=60/180*pi;

delta=5.5e-7*100;% time step
Vcap(1)=0;
Iind(1)=0;
tottime=3*2*pi/w;

for step=1:tottime/delta;
   
 t=step*delta;

 Vcap(step+1)= Vcap(step) + delta*(Iind(step)/C);
 Iind(step+1)= Iind(step) + delta*(-R/L*Iind(step) - Vcap(step)/L + Vm/L*cos(w*t + phi));
end;

versus=0:delta*w:6*pi;
plot(versus,Iind);
title('Inductor Current Waveform for the RLC Circuit');xlabel('wt');







