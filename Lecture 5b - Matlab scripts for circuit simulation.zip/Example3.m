% Main Matlab routine
clear all;
%Part 2, problem 1.
global R;
global L;
global C;

R=input('Input the resistance in ohms: ');
L=input('Input the inductance in henrys: ');
C=input('Input the capacitance in farads: ');

tottime=0.4e-3;

[tout,yout] = ode45('funcp2', [0 tottime], [0 0]);
figure(1),plot(tout, yout(:,1));
title('Capacitor Voltage Waveform for the RLC Circuit');xlabel('t');

figure(2),plot(tout, yout(:,2),tout, (80-yout(:,1))/R);
title('Inductor & Resistor Current and  Waveforms for the RLC Circuit');xlabel('t');
legend('i_L', 'i_R');


