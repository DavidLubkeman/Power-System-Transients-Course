% Function used by integration routine
function Xprime=funcp2(t,X)

%set of first-order differential equations for RLC circuit
global R;
global L;
global C;

% X1=Vc and X2=IL
% i=[Vc IL]
Xprime(1,1)= -X(1)/(R*C) - X(2)/C + 80/(R*C); % dVc/dt
Xprime(2,1)= X(1)/L - 100/L; 					 % diL / dt

