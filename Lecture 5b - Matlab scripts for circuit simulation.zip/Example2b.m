clear all;
% part 1, problem 3
global R;
global L;
global C;
global Vm;
global w;
global ang;

R=input('Input the resistance in ohms: ');
L=input('Input the inductance in henrys: ');
C=input('Input the capacitance in farads: ');
Vm=input('Input the Voltage Magnitude: ');
w=input('Input the ang. freq : ');
ang=input('Input the Voltage angle: ');

tottime=3*2*pi/w;

[tout,yout] = ode45('funcp1', [0 tottime], [0 0]);
figure(2),plot(tout*w, yout(:,2));
title('Inductor Current Waveform for the RLC Circuit');xlabel('wt');