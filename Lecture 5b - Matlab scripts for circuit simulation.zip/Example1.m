clear all;
% part 1, problem 1
R=input('Input the resistance in ohms: ');
L=input('Input the inductance in henrys: ');
Vm=input('Input the Voltage Magnitude: ');
w=input('Input the ang. freq : ');
ang=input('Input the Voltage angle: ');

phi=ang/180*pi;
theta=atan(w*L/R);

delta=10^(-4);
Ieuler(1)=0;
Icalc(1)=0;
tottime=3*2*pi/w;

for step=1:tottime/delta;

 t=step*delta;

 Ieuler(step+1)= Ieuler(step) + delta*(-R/L*Ieuler(step) + Vm/L*cos(w*t + phi));
 Icalc(step +1)= Vm/sqrt(R^2+(w*L)^2) * (cos(w*t+phi-theta) - cos(phi-theta)*exp(-R/L*t));

end;

%dump output
versus=0:delta*w:6*pi;

plot(versus,Ieuler); hold on;
plot(versus,Icalc,'r-.');

title('Current Waveforms for the RL Circuit');xlabel('wt');
axis([0 6*pi -3 3]);
legend('Euler Iteration','Calculated Current');
