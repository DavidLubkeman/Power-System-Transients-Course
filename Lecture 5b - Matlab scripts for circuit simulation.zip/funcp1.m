function x_prime=funcp1(t,x)

%set of first-order differential equations for RLC circuit
global R;
global L;
global C;
global Vm;
global w;
global ang;

phi=ang/180*pi;

% x1=Vc and i2=Il
% x=[x1 x2]
x_prime(1,1)= (1/C)*x(2); 
x_prime(2,1)= -R/L*x(2) -1/(L)*x(1) + Vm/L*cos(w*t + phi); 

